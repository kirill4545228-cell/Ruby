# Ruby Mod (Forge 1.20.1)
Руда рубина (генерируется в Overworld), блок рубина, рубиновая кирка и меч, Огненный посох (ПКМ — огненный шар, перезарядка 1 с).

Сборка: JDK 17 + Gradle 8.1+ (`gradle build`) или импорт в IntelliJ IDEA как Gradle-проект.
Готовый jar: build/libs/rubymod-1.20.1-1.0.0.jar → в папку mods (Forge 47.x).
