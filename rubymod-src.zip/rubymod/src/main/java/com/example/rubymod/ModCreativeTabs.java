package com.example.rubymod;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RubyMod.MODID);

    public static final RegistryObject<CreativeModeTab> RUBY_TAB = TABS.register("ruby_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rubymod"))
                    .icon(() -> new ItemStack(ModItems.RUBY.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.RUBY.get());
                        out.accept(ModItems.RUBY_ORE.get());
                        out.accept(ModItems.RUBY_BLOCK.get());
                        out.accept(ModItems.RUBY_PICKAXE.get());
                        out.accept(ModItems.RUBY_SWORD.get());
                        out.accept(ModItems.FIRE_STAFF.get());
                    }).build());
}
